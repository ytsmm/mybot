from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans

def vectorizer(text):
    return text